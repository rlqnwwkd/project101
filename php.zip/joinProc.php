﻿<?php	
	$conn = mysqli_connect("localhost", "root", 111111);
	mysqli_select_db($conn, "gms");
	
	if (mysqli_connect_errno($conn)){echo "Fail";}
	else{	
		$name = $_POST["name"];
		$gender = $_POST["gender"];
		$age = $_POST["age"];            
		$photo = $_FILES['photo'] ['name']; 
		$height = $_POST["height"]; 
		$weight = $_POST["weight"];            
		$phoneNumber = $_POST["phoneNumber"];            
		$nfcnumber = 333044282;
		$trainerinfo = 1;

		if(move_uploaded_file($_FILES['photo']['tmp_name'],$photo)){
			echo "success!! ";
		}
		
		$sql = "INSERT INTO trainee(name, gender, age, photo, height, weight, phoneNumber, regdate, nfcnumber, trainerInfo) VALUES('".$name."','".$gender."',$age,'".$photo."',$height,$weight,'".$phoneNumber."',now(),'".$nfcnumber."',$trainerinfo);";

	if (mysqli_query($conn, $sql)) {
		echo "Join Complete!";
	} else {
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}

	}
	mysqli_close($conn);
?>