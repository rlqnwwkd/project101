﻿<?php
	$conn = mysqli_connect("localhost", "root", 111111, "gms");

	if (mysqli_connect_errno($conn)){echo "Fail";}
	else{
		$request = $_GET['request'];
		
		if($request == 'add' ){		
			$traineeid = $_GET[traineeid];
			$year= $_GET[year];
			$month = $_GET[month];
			$day = $_GET[day];
			$exercisename = $_GET[exercisename];
			$exercisevolume = $_GET[exercisevolume];
		}

		$sql = "INSERT INTO workoutschedule (year,month,day,exercisename,exercisevolume,traineeid) VALUES ($year,$month,$day,'".$exercisename."',$exercisevolume,$traineeid);";
		
		if (mysqli_query($conn, $sql)) {
			echo "New record created successfully";
		} else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
	}
	mysqli_close($conn);
?>