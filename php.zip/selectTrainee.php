﻿<?php
	$conn = mysqli_connect("localhost", "root", 111111, "gms");

	if (mysqli_connect_errno($conn)){echo "Fail";}
	else{
		$sql = "SELECT * FROM trainee;";
		$result = mysqli_query($conn,$sql);
		
		while($row = mysqli_fetch_array($result)){
			echo  $row['name'].",";
			echo $row['photo'];
			echo  "\n";
		}
		
	mysqli_close($conn);
	}
?>