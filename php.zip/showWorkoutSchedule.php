﻿<?php
	$conn = mysqli_connect("localhost", "root", 111111, "gms");

	if (mysqli_connect_errno($conn)){echo "Fail";}
	else{
		$request = $_GET['request'];
		
		if($request == 'show' ){		
			$traineeid = $_GET[traineeid];
			$year= $_GET[year];
			$month = $_GET[month];
			$day = $_GET[day];
		}

		$sql = "SELECT * FROM workoutschedule WHERE traineeid=".$traineeid." AND year=".$year." AND month=".$month." AND day=".$day.";";
		
	
		$result = mysqli_query($conn,$sql);
		
		while($row = mysqli_fetch_array($result)){
			echo  $row['exercisename'].",";
			echo $row['exercisevolume'];
			echo  "\n";
		}
	}
	mysqli_close($conn);
?>